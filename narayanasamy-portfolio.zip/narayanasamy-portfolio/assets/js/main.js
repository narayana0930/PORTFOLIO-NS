/**
 * Portfolio Interactive Scripts
 * Narayanasamy N
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. THEME TOGGLE (Dark / Light)
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon = document.getElementById('themeIcon');
  const html = document.documentElement;

  // Initialize theme from storage or default to dark
  const savedTheme = localStorage.getItem('portfolio-theme') || 'dark';
  if (savedTheme === 'light') {
    html.classList.remove('dark');
    themeIcon.classList.remove('fa-sun');
    themeIcon.classList.add('fa-moon');
  } else {
    html.classList.add('dark');
    themeIcon.classList.remove('fa-moon');
    themeIcon.classList.add('fa-sun');
  }

  themeToggle.addEventListener('click', () => {
    if (html.classList.contains('dark')) {
      html.classList.remove('dark');
      localStorage.setItem('portfolio-theme', 'light');
      themeIcon.classList.remove('fa-sun');
      themeIcon.classList.add('fa-moon');
    } else {
      html.classList.add('dark');
      localStorage.setItem('portfolio-theme', 'dark');
      themeIcon.classList.remove('fa-moon');
      themeIcon.classList.add('fa-sun');
    }
  });

  // 2. MOBILE MENU DRAWER
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const mobileMenu = document.getElementById('mobileMenu');

  mobileMenuBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
  });

  // Close mobile menu on link click
  mobileMenu.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      mobileMenu.classList.add('hidden');
    });
  });

  // 3. DYNAMIC ROLE TYPING ANIMATION
  const typedRoleElement = document.getElementById('typedRole');
  const roles = [
    'Full-Stack Development',
    'Android Apps (Compose & Kotlin)',
    'AI & Machine Learning',
    'B.Tech IT @ KCT Coimbatore'
  ];

  let roleIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  let typingSpeed = 90;

  function typeRole() {
    const currentRole = roles[roleIndex];

    if (isDeleting) {
      typedRoleElement.textContent = currentRole.substring(0, charIndex - 1);
      charIndex--;
      typingSpeed = 40;
    } else {
      typedRoleElement.textContent = currentRole.substring(0, charIndex + 1);
      charIndex++;
      typingSpeed = 90;
    }

    if (!isDeleting && charIndex === currentRole.length) {
      isDeleting = true;
      typingSpeed = 1600; // Pause at end of word
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      roleIndex = (roleIndex + 1) % roles.length;
      typingSpeed = 300; // Pause before typing next word
    }

    setTimeout(typeRole, typingSpeed);
  }

  typeRole();

  // 4. PROJECT CATEGORY FILTER
  const filterBtns = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      // Toggle active button style
      filterBtns.forEach((b) => {
        b.classList.remove('bg-blue-600', 'text-white', 'active');
        b.classList.add('bg-gray-100', 'dark:bg-darkcard', 'text-gray-600', 'dark:text-gray-300');
      });

      btn.classList.remove('bg-gray-100', 'dark:bg-darkcard', 'text-gray-600', 'dark:text-gray-300');
      btn.classList.add('bg-blue-600', 'text-white', 'active');

      const filterValue = btn.getAttribute('data-filter');

      projectCards.forEach((card) => {
        const cardCategory = card.getAttribute('data-category');
        if (filterValue === 'all' || cardCategory === filterValue) {
          card.style.display = 'flex';
          card.classList.add('animate-fadeIn');
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // 5. CONTACT FORM TO DIRECT EMAIL DISPATCH
  const contactForm = document.getElementById('contactForm');
  const formFeedback = document.getElementById('formFeedback');

  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('senderName').value.trim();
    const email = document.getElementById('senderEmail').value.trim();
    const subject = document.getElementById('senderSubject').value.trim();
    const message = document.getElementById('senderMessage').value.trim();

    if (!name || !email || !message) {
      formFeedback.textContent = 'Please fill out all required fields.';
      formFeedback.classList.remove('hidden', 'text-emerald-500');
      formFeedback.classList.add('text-red-500');
      return;
    }

    // Format mailto link
    const mailtoSubject = encodeURIComponent(`[Placement/Inquiry] ${subject} - from ${name}`);
    const mailtoBody = encodeURIComponent(
      `Hi Narayanasamy,\n\nName: ${name}\nEmail: ${email}\n\nMessage:\n${message}\n\nSent from your portfolio website.`
    );

    formFeedback.textContent = 'Opening your email client to send message...';
    formFeedback.classList.remove('hidden', 'text-red-500');
    formFeedback.classList.add('text-emerald-500');

    window.location.href = `mailto:narinenaresh12@gmail.com?subject=${mailtoSubject}&body=${mailtoBody}`;

    setTimeout(() => {
      contactForm.reset();
      formFeedback.textContent = 'Message template created! Ready to dispatch.';
    }, 1500);
  });
});

